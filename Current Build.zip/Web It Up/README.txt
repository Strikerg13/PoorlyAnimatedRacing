To run the game, right click the "index' HTML file, select "open with", and choose firefox.

Tried it in Chrome & IE but it says it's not supported.